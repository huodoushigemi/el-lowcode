export default {
  is: 'ElCarouselItem',
  label: 'carousel-item',
  drag: false,
  defaultProps: () => ({
    children: []
  })
}